Sender script
-------------
Usage:
python send_file.py <path-to-file> [--chunk-size 262144] [--priority high]
